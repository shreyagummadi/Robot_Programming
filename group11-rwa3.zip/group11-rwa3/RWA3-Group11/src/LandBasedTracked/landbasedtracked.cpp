#include "landbasedtracked.h"
#include <iostream>


//----Methods Definitions----


// Move the robot up in the maze
void rwa3::LandBasedTracked::GoUp(int x, int y){
    std::cout << "LandBasedTracked::GoUp is called\n";
}
// Move the robot down in the maze
void rwa3::LandBasedTracked::GoDown(int x, int y){
    std::cout << "LandBasedTracked::GoDown is called\n";
}
// Move the robot left in the maze
void rwa3::LandBasedTracked::TurnLeft(int x, int y){
    std::cout << "LandBasedTracked::TunLeft is called\n";
}
// Move the robot right in the maze
void rwa3::LandBasedTracked::TurnRight(int x, int y){
    std::cout << "LandBasedTracked::TurnRight is called\n";
}
// Arm picks up an object
void rwa3::LandBasedTracked::PickUp(std::string object){
    LandBasedRobot::PickUp(object);
    std::cout << "LandBasedTracked::PickUp is called\n";
}
// Arm releases an object
void rwa3::LandBasedTracked::Release(std::string object){
    LandBasedRobot::Release(object);
    std::cout << "LandBasedTracked::Release is called\n";
}


//----Derived class constructor definition----

rwa3::LandBasedTracked::LandBasedTracked(std::string name, int x, int y)
    : LandBasedRobot(name, x, y){
//        std::cout << "LandBasedTracked()::LandBasedTacked() Derived class constructor is called" << std::endl;
        track_type = new std::string;//dynamically allocate space on the heap for std::string data type
        *track_type = "";//initialize pointer
    } 
//----Derived Class Copy Constructor definition----
   
rwa3::LandBasedTracked::LandBasedTracked(const LandBasedTracked &source)
    : LandBasedRobot(source){
//        std::cout << "LandBasedTracked() copy constructor is called" << std::endl;
        track_type = new std::string;//dynamically allocate space on the heap for std::string data type
        *track_type = *source.track_type;//copy value of pointer
    }