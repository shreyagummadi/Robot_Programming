#pragma once
#include "landbasedrobot.h"


namespace rwa3{
    
/**
* @brief Derived Class LandBasedTracked is of type concrete, which is single and public inherits from LandBasedRobot
* @return return the atributes, methods, constructor/destructors, and accesors and mutators
*/

class LandBasedTracked : public LandBasedRobot{


    public:

//----constructor & destructor----

/**
* @brief Costructors and destructor in class LandBasedTracked are public, and are used to make obects using deep copy from base class LandBasedRobot
* @return return the attribute from LandBasedTracked class
*/

    //---Derived class constructor initialize---
        LandBasedTracked(std::string name, int x, int y);

    //---Derived Class Copy Constructor initialize---
        LandBasedTracked(const LandBasedTracked &source);

    //---Derived Class Destructor---
        virtual ~LandBasedTracked(){
//       std::cout << "LandBasedTracked::~LandBasedTracked() is called" << std::endl;
        delete track_type;//free allocated space on the heap created by new pointer
    }

/**
* @brief Methods are public, dynamic binding, virtual and override in class LandBasedTracked, and work like functions.
* @return return the function veing called by the derived class.
*/

//----Methods Prototypes----

    	virtual void GoUp(int x, int y) override;// Move the robot up in the maze
    	virtual void GoDown(int x, int y) override;// Move the robot down in the maze
    	virtual void TurnLeft(int x, int y) override;// Move the robot left in the maze
    	virtual void TurnRight(int x, int y) override;// Move the robot right in the maze
    	virtual void PickUp(std::string object) override;// Arm picks up an object
    	virtual void Release(std::string object) override;// Arm releases an object

/**
 * @brief protected method atributes that can be used only by class LandBasedTracked
 * @param *track_type
 * @return this attibute is a pointer to a heap memory location and it return the type of track mounted on the robot.
 */

//----Methods Atributes----

    protected:

        std::string *track_type;// Type of track mounted on the robot.



};//--class LandBasedTracked

}//--name namespace rwa3

