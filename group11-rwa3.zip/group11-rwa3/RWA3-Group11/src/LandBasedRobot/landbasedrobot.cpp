#include "landbasedrobot.h"
#include <iostream>


//----Methods Definitions----

//Function for picking up object of type std::string
void rwa3::LandBasedRobot::PickUp(std::string object){
//    std::cout << "LandBasedRobot::PickUp is called\n";
}
//Function for releasing object of type std::string
void rwa3::LandBasedRobot::Release(std::string object){
//    std::cout << "LandBasedRobot::Release is called\n";
}

//----constructor definition----

rwa3::LandBasedRobot::LandBasedRobot(std::string name,int x, int y)
: name_{name},x_{x},y_{y}{};
//        std::cout << "LandBasedRobot::LandBasedRobot() constructor is called" << std::endl;
    

//----copy constructor definition----
rwa3::LandBasedRobot::LandBasedRobot(const LandBasedRobot &source)
: name_{source.name_}, x_{source.x_}, y_{source.y_}{};
//        std::cout << "LandBasedRobot::LandBasedRobot() copy constructor is called" << std::endl; 



