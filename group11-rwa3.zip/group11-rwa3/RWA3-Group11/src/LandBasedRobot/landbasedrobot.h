#pragma once
#include <string>


namespace rwa3{
    
/**
* @brief Class LandBasedRobot is the base class which is an abstract type
* @return return the only the methods that are being called by the derived classes.
*/
    
class LandBasedRobot{

// atributes, methods, constructor/destructors, and accesors and mutators
    public:
//----constructor & destructor----

/**
* @brief Costructors and destructor in class LandBasedRobot are public, and are used to make other obects from derived classes
* @return return the attribute from other classes
*/

    //---constructor initialize---
        LandBasedRobot(std::string name, int x, int y);//name is used to initialize the name_ attribute, x is used to initialize the x_ attribute, and y is used to initialize the y_ attribute.

    
    //---Copy Constructor initialize---
    	LandBasedRobot(const LandBasedRobot &source);//used to construct other objects from the same class

    
    //---Destructor---	
    	virtual ~LandBasedRobot(){
//        std::cout << "LandBasedRobot::~LandBasedRobot() is called" << std::endl;
    }

/**
* @brief Methods are public and virtual in clas LandBasedRobot, and work like functions.
* @return return the function veing called by the derived class.
*/

//----Methods Prototypes----

    	virtual void GoUp(int x,int y) = 0;// Move the robot up in the maze.
    	virtual void GoDown(int x,int y) = 0;// Move the robot down in the maze.
    	virtual void TurnLeft(int x,int y) = 0;// Move the robot left in the maze.
        virtual void TurnRight(int x,int y) = 0;// Move the robot right in the maze.
    	virtual void PickUp(std::string object);// Arm picks up an object.
    	virtual void Release(std::string object);// Arm releases an object.

//----accessors & mutators----

/**
* @brief accessors are constant and mutators void in class LandBasedRobot, both are public
* @return return the option to set new values in the varibles or to read the current variable of private or protected attributes.
*/

    //---accessors---
        int get_x() const{
            return x_;
        }
        int get_y() const{
            return y_;
        }
        double get_speed() const{
            return speed_;
        }
        
    //---mutators---
        void set_x(int x){
            x_= x;
        }
        void set_y(int y){
            y_= y;
        }
        void set_speed(double speed){
            speed_= speed;
        }



//----Methods Atributes----

    protected:

/**
 * @brief protected method atributes that can be used by any function by using the available accesors and mutators.
 * @param name_
 * @param speed_
 * @param width_
 * @param length_
 * @param capacity_
 * @param x_
 * @param y_
 * @return the specific attributed called from an accesor or mutator (string, double, int) 
 */

        std::string name_;// Name of the robot.
        double speed_;// Driving speed of the robot.
        double width_;// Width of the base of the robot.
        double length_;// Length of the base of the robot.
        double height_;// Height of the base of the robot.
        double capacity_;// Payload of the arm.
        int x_;// X coordinate of the robot in the maze.
        int y_;// Y coordinate of the robot in the maze.


};//--class LandBasedRobot

}//--name namespace rwa3

