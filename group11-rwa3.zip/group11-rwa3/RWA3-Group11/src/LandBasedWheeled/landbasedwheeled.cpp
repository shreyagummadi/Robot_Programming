#include "landbasedwheeled.h"
#include <iostream>


//----Methods Definitions----

// The robot can increase its speed, which is translated by the number of cells in the maze that the robot can traverse in each step.
void rwa3::LandBasedWheeled::SpeedUp(int num_cells){
    std::cout << "LandBasedWheeled::SpeedUp is called\n";
}
// Move the robot up in the maze
void rwa3::LandBasedWheeled::GoUp(int x, int y){
    std::cout << "LandBasedWheeled::GoUp is called\n";
}
// Move the robot down in the maze
void rwa3::LandBasedWheeled::GoDown(int x, int y){
    std::cout << "LandBasedWheeled::GoDown is called\n";
}
// Move the robot left in the maze
void rwa3::LandBasedWheeled::TurnLeft(int x, int y){
    std::cout << "LandBasedWheeled::TunLeft is called\n";
}
// Move the robot right in the maze
void rwa3::LandBasedWheeled::TurnRight(int x, int y){
    std::cout << "LandBasedWheeled::TurnRight is called\n";
}
// Arm picks up an object
void rwa3::LandBasedWheeled::PickUp(std::string object){
    LandBasedRobot::PickUp(object);
    std::cout << "LandBasedWheeled::PickUp is called\n";
}
// Arm releases an object
void rwa3::LandBasedWheeled::Release(std::string object){
    LandBasedRobot::Release(object);
    std::cout << "LandBasedWheeled::Release is called\n";
}


//----Derived class constructor definition----
rwa3::LandBasedWheeled::LandBasedWheeled(std::string name, int x, int y)
    	: LandBasedRobot(name, x, y){
//        std::cout << "LandBasedWheeled::LandBasedWheeled() Derived class constructor is called" << std::endl;
        wheel_type = new std::string;//dynamically allocate space on the heap for std::string data type
        *wheel_type = "";//initialize pointer
    }
    
//----Derived Class Copy Constructor definition----
rwa3::LandBasedWheeled::LandBasedWheeled(const LandBasedWheeled &source)
    	: LandBasedRobot(source){
//        std::cout << "LandBasedWheeled::LandBasedWheeled() copy constructor is called" << std::endl;
        wheel_type = new std::string;//dynamically allocate space on the heap for std::string data type
        *wheel_type = *source.wheel_type;//copy value of pointer attribute
        wheel_number = source.wheel_number;//copy value of wheel_number
    }