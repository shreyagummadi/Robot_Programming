#pragma once
#include "landbasedrobot.h"


namespace rwa3{

/**
* @brief Derived Class LandBasedWheeled is of type concrete, which is single and public inherits from LandBasedRobot
* @return return the atributes, methods, constructor/destructors, and accesors and mutators
*/

class LandBasedWheeled : public LandBasedRobot{


    public:
    
//----constructor & destructor----

/**
* @brief Costructors and destructor in class LandBasedWheeled are public, and are used to make obects using deep copy from base class LandBasedRobot
* @return return the attribute from LandBasedWheeled class
*/

    //---Derived class constructor initialize---
    	LandBasedWheeled(std::string name, int x, int y);

    //---Derived Class Copy Constructor---
    	LandBasedWheeled(const LandBasedWheeled &source);

    //---Derived Class Destructor---
    	virtual ~LandBasedWheeled(){
//        std::cout << "LandBasedWheeled::~LandBasedWheeled() Derived Class Destructor is called" << std::endl;
        delete wheel_type;//free allocated space on the heap created by new
    }

/**
* @brief Methods are public, dynamic binding, virtual and override in class LandBasedWheeled, and work like functions.
* @return return the function veing called by the derived class.
*/

//----Methods Prototypes----

        void SpeedUp(int);// The robot can increase its speed, which is translated by the number of cells in the maze that the robot can traverse in each step.        
    	virtual void GoUp(int x, int y) override;// Move the robot up in the maze
    	virtual void GoDown(int x, int y) override;// Move the robot down in the maze
    	virtual void TurnLeft(int x, int y) override;// Move the robot left in the maze
    	virtual void TurnRight(int x, int y) override;// Move the robot right in the maze
    	virtual void PickUp(std::string object) override;// Arm picks up an object
    	virtual void Release(std::string object) override;// Arm releases an object

/**
 * @brief protected method atributes that can be used only by class LandBasedWheeled
 * @param wheel_number
 * @param *wheel_type
 * @return the first attribute return an integer and the second attibute is a pointer to a heap memory location and it return Number of wheels, and Type of wheels (respectivaly) mounted on the robot.
 */

//----Methods Atributes----

    protected:

        int wheel_number;// Number of wheels mounted on the robot.
        std::string *wheel_type;// Type of wheels mounted on the robot.

};//--class LandBasedWheeled

}//--name namespace rwa3

