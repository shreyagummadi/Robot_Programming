var searchData=
[
  ['min',['MIN',['../main_8cpp.html#a3acffbd305ee72dcd4593c0d8af64a4f',1,'main.cpp']]]
];
