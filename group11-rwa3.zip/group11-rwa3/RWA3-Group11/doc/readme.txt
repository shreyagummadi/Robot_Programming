# ENPM809Y_Group11: Introduction to Robot Programming 
# Assignment 3: OOP, Inheritance, and Polymorphism


Project Statement
========
For this assignment, we are not asked to write code that will drive robots in a maze. We are tasked to develop only the structure of a project using object-oriented programming, inheritance, and polymorphism, that will be used in the ﬁnal project to drive robots in a maze. 


It is currently hosted on GitHub at 

https://github.com/sully892/Cu_Ag_Au/RWA3-Group11


Files
========
 
There is one file for this project:
	group11-rwa3.zip

To run the file, extract and open the workspace in any IDE, build, and run the main.cpp file. 

The program consists of the following files:

main.cpp
landbasedrobot.h
landbasedrobot.cpp
landbasedtracked.h
landbasedtracked.cpp
landbasedwheeled.h
landbasedwheeled.cpp

Overview
========

* The scenario uses two types of mobile robotic arms that can drive and pick up objects in a maze

* The ﬁrst robot belongs to the C++ class LandBasedWheeled, which is a derived concrete class

* The second robot belongs to the C++ class LandBasedTracked, which is a derived concrete class

* Both classes derive from the base class LandBasedRobot, which is an abstract base class


User Inputs
-----

Currently there are no user inputs implemented in the program

Program Output
------

* The program displays to the console which method is being called by the LandBasedWheeled and LandBasedTracked class as they called by main.cpp

* The program will output the following to the console as specified by the assignment rules:

		LandBasedWheeled::GoUp is called
		LandBasedWheeled::TurnRight is called
		LandBasedWheeled::PickUp is called
		LandBasedWheeled::TurnLeft is called
		LandBasedWheeled::GoDown is called
		LandBasedWheeled::Release is called
		---------------------------------------
		LandBasedTracked::GoUp is called
		LandBasedTracked::TurnLeft is called
		LandBasedTracked::PickUp is called
		LandBasedTracked::GoDown is called
		LandBasedTracked::TurnRight is called
		LandBasedTracked::Release is called


To run the file:
------

	-Step 1: Extract and open the workspace in any IDE, then build and run the main.cpp file. 
		~The zip file might contains adjacent files, make sure to that it is stored in the workspace for the code to run. Otherwise. specify the location address in the code.

	-Step 2: Read the outputs from the terminal.


Implementation
-----

The program has three classes: 
LandBasedRobot
LandBasedTracked
LandBasedWheeled

LandBasedRobot is an abstract base class that is inherited (publicly) by the two derived concrete classes LandBasedTracked and LandBasedWheeled. This program will act as the structure for the final project which will consist of two types of robots (wheeled and tracked) that will navigate a maze, and will be capable of picking up and releasing various objects contained in the maze.
