#include "landbasedrobot.h"

//Function for picking up object of type std::string
void rwa3::LandBasedRobot::PickUp(std::string object){
//    std::cout << "LandBasedRobot::PickUp() is called" << std::endl;
}
//Function for releasing object of type std::string
void rwa3::LandBasedRobot::Release(std::string object){
//    std::cout << "LandBasedRobot::Release() is called" << std::endl;
}