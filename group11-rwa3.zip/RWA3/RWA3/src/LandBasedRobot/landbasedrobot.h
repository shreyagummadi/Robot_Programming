#pragma once

#include <iostream>
#include <string>

namespace rwa3{

class LandBasedRobot{
    public:
    //Constructor
    LandBasedRobot(std::string name, int x, int y)
    : name_{name}, x_{x}, y_{y}{
//        std::cout << "LandBasedRobot::LandBasedRobot() is called" << std::endl;
    }
    
    //Copy Constructor
    LandBasedRobot(const LandBasedRobot &source)
    : name_{source.name_}, x_{source.x_}, y_{source.y_}{
//        std::cout << "LandBasedRobot::LandBasedRobot() copy constructor is called" << std::endl; 
    } 
    
    //Destructor
    virtual ~LandBasedRobot(){
//        std::cout << "LandBasedRobot::~LandBasedRobot() is called" << std::endl;
    }
    
    //Methods
    virtual void GoUp(int x, int y) = 0;// Move the robot up in the maze
    virtual void GoDown(int x, int y) = 0;// Move the robot down in the maze
    virtual void TurnLeft(int x, int y) = 0;// Move the robot left in the maze
    virtual void TurnRight(int x, int y) = 0;// Move the robot right in the maze
    virtual void PickUp(std::string object);// Arm picks up an object
    virtual void Release(std::string object);// Arm releases an object
    
    //Accessors
    int get_x() const{
        return x_;
    }
    int get_y() const{
        return y_;
    }
    
//Attributes    
protected:
    std::string name_;// Name of the robot
    double speed_;// Driving speed of the robot
    double width_;// Width of the base of the robot
    double length_;// Length of the base of the robot
    double height_;// Height of the base of the robot
    double capacity_;// Payload of the arm
    int x_;// X coordinate of the robot in the maze
    int y_;// Y coordinate of the robot in the maze
};//class LandBasedRobot

}//namespace rwa3
