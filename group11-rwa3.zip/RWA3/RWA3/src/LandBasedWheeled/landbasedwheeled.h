#pragma once
#include "landbasedrobot.h"

namespace rwa3{
//Derived Class LandBasedWheeled which publicly inherits from LandBasedRobot
class LandBasedWheeled : public LandBasedRobot{
    public:
//Derived Class Constructor
    LandBasedWheeled(std::string name, int x, int y)
    : LandBasedRobot(name, x, y){
//        std::cout << "LandBasedWheeled::LandBasedWheeled() is called" << std::endl;
        wheel_type = new std::string;//dynamically allocate space on the heap for std::string data type
        *wheel_type = "";//initialize pointer
    }
// Derived Class Copy Constructor
    LandBasedWheeled(const LandBasedWheeled &source)
    : LandBasedRobot(source){
//        std::cout << "LandBasedWheeled::LandBasedWheeled() copy constructor is called" << std::endl;
        wheel_type = new std::string;//dynamically allocate space on the heap for std::string data type
        *wheel_type = *source.wheel_type;//copy value of pointer attribute
        wheel_number = source.wheel_number;//copy value of wheel_number
    }
// Derived Class Destructor
    virtual ~LandBasedWheeled(){
//        std::cout << "LandBasedWheeled::~LandBasedWheeled() is called" << std::endl;
        delete wheel_type;//free allocated space on the heap created by new
    }
    
    void SpeedUp(int num_cells);// The robot can increase its speed, which is translated by the number of cells in the maze that the robot can traverse in each step.
    virtual void GoUp(int x, int y) override;// Move the robot up in the maze
    virtual void GoDown(int x, int y) override;// Move the robot down in the maze
    virtual void TurnLeft(int x, int y) override;// Move the robot left in the maze
    virtual void TurnRight(int x, int y) override;// Move the robot right in the maze
    virtual void PickUp(std::string object) override;// Arm picks up an object
    virtual void Release(std::string object) override;// Arm releases an object
    
protected:
    int wheel_number;// Number of wheels mounted on the robot
    std::string *wheel_type;// Type of wheels mounted on the robot
};

}