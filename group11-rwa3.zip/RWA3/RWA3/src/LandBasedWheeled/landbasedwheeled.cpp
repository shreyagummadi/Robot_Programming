#include "landbasedwheeled.h"
#include <iostream>

// The robot can increase its speed, which is translated by the number of cells in the maze that the robot can traverse in each step.
void rwa3::LandBasedWheeled::SpeedUp(int num_cells){
    std::cout << "LandBasedWheeled::SpeedUp() is called" << std::endl;
}
// Move the robot up in the maze
void rwa3::LandBasedWheeled::GoUp(int x, int y){
    std::cout << "LandBasedWheeled::GoUp() is called" << std::endl;
}
// Move the robot down in the maze
void rwa3::LandBasedWheeled::GoDown(int x, int y){
    std::cout << "LandBasedWheeled::GoDown() is called" << std::endl;
}
// Move the robot left in the maze
void rwa3::LandBasedWheeled::TurnLeft(int x, int y){
    std::cout << "LandBasedWheeled::TurnLeft() is called" << std::endl;
}
// Move the robot right in the maze
void rwa3::LandBasedWheeled::TurnRight(int x, int y){
    std::cout << "LandBasedWheeled::TurnRight() is called" << std::endl;
}
// Arm picks up an object
void rwa3::LandBasedWheeled::PickUp(std::string object){
    LandBasedRobot::PickUp(object);
    std::cout << "LandBasedWheeled::PickUp() is called" << std::endl;
}
// Arm releases an object
void rwa3::LandBasedWheeled::Release(std::string object){
    LandBasedRobot::Release(object);
    std::cout << "LandBasedWheeled::Release() is called" << std::endl;
}