#pragma once
#include "landbasedrobot.h"

namespace rwa3{
//Derived Class LandBasedTracked which publicly inherits from LandBasedRobot
class LandBasedTracked : public LandBasedRobot{
public:
//Derived Class Constructor
    LandBasedTracked(std::string name, int x, int y)
    : LandBasedRobot(name, x, y){
//        std::cout << "LandBasedTracked()::LandBasedTacked() is called" << std::endl;
        track_type = new std::string;//dynamically allocate space on the heap for std::string data type
        *track_type = "";//initialize pointer
    }
// Derived Class Copy Constructor
    LandBasedTracked(const LandBasedTracked &source)
    : LandBasedRobot(source){
//        std::cout << "LandBasedTracked() copy constructor is called" << std::endl;
        track_type = new std::string;//dynamically allocate space on the heap for std::string data type
        *track_type = *source.track_type;//copy value of pointer
    }
// Derived Class Destructor
    virtual ~LandBasedTracked(){
//        std::cout << "LandBasedWheeled::~LandBasedWheeled() is called" << std::endl;
        delete track_type;//free allocated space on the heap created by new
    }
    virtual void GoUp(int x, int y) override;// Move the robot up in the maze
    virtual void GoDown(int x, int y) override;// Move the robot down in the maze
    virtual void TurnLeft(int x, int y) override;// Move the robot left in the maze
    virtual void TurnRight(int x, int y) override;// Move the robot right in the maze
    virtual void PickUp(std::string object) override;// Arm picks up an object
    virtual void Release(std::string object) override;// Arm releases an object
    
protected:
    std::string *track_type;// Type of track mounted on the robot
};

}