#include "landbasedtracked.h"

// Move the robot up in the maze
void rwa3::LandBasedTracked::GoUp(int x, int y){
    std::cout << "LandBasedTracked::GoUp() is called" << std::endl;
}
// Move the robot down in the maze
void rwa3::LandBasedTracked::GoDown(int x, int y){
    std::cout << "LandBasedTracked::GoDown() is called" << std::endl;
}
// Move the robot left in the maze
void rwa3::LandBasedTracked::TurnLeft(int x, int y){
    std::cout << "LandBasedTracked::TurnLeft() is called" << std::endl;
}
// Move the robot right in the maze
void rwa3::LandBasedTracked::TurnRight(int x, int y){
    std::cout << "LandBasedTracked::TurnRight() is called" << std::endl;
}
// Arm picks up an object
void rwa3::LandBasedTracked::PickUp(std::string object){
    LandBasedRobot::PickUp(object);
    std::cout << "LandBasedTracked::PickUp() is called" << std::endl;
}
// Arm releases an object
void rwa3::LandBasedTracked::Release(std::string object){
    LandBasedRobot::Release(object);
    std::cout << "LandBasedTracked::Release() is called" << std::endl;
}