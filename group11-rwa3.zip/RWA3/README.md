# ENPM809Y_Group11: Introduction to Robot Programming 
# Assignment 3: OOP, Inheritance, and Polymorphism


Project Statement
========
For this assignment, we are not asked to write code that will drive robots in a maze. We are tasked to develop only the structure of a project using object-oriented programming, inheritance, and polymorphism, that will be used in the ﬁnal project to drive robots in a maze. 


It is currently hosted on GitHub at 

https://github.com/sully892/Cu_Ag_Au/RWA3-Group11


Files
========
 
There is one file for this project:
	group11-rwa3.zip

To run the file, extract and open the workspace in any IDE, build, and run the main.cpp file. 

The program consists of the following files:

main.cpp
landbasedrobot.h
landbasedrobot.cpp
landbasedtracked.h
landbasedtracked.cpp
landbasedwheeled.h
landbasedwheeled.cpp

Overview
========

* The scenario uses two types of mobile robotic arms that can drive and pick up objects in a maze

* The ﬁrst robot belongs to the C++ class LandBasedWheeled, which is a derived concrete class

* The second robot belongs to the C++ class LandBasedTracked, which is a derived concrete class

* Both classes derive from the base class LandBasedRobot, which is an abstract base class


User Inputs
-----

Currently there are no user inputs implemented in the program

Program Output
------

* The program displays to the console which method is being called by the LandBasedWheeled and LandBasedTracked class as they called by main.cpp

* The program will output the following to the console as specified by the assignment rules:

LandBasedWheeled::GoUp is called
LandBasedWheeled::TurnRight is called
LandBasedWheeled::PickUp is called
LandBasedWheeled::TurnLeft is called
LandBasedWheeled::GoDown is called
LandBasedWheeled::Release is called
-------------------------------------------------------------------
LandBasedTracked::GoUp is called
LandBasedTracked::TurnLeft is called
LandBasedTracked::PickUp is called
LandBasedTracked::GoDown is called
LandBasedTracked::TurnRight is called
LandBasedTracked::Release is called


Implementation
-----

The program has three classes: 
LandBasedRobot
LandBasedTracked
LandBasedWheeled

LandBasedRobot is an abstract base class that is inherited (publicly) by the two derived concrete classes LandBasedTracked and LandBasedWheeled. This program will act as the structure for the final project which will consist of two types of robots (wheeled and tracked) that will navigate a maze, and will be capable of picking up and releasing various objects contained in the maze.

LandBasedRobot Class (public) Methods
-----

1. LandBasedRobot(std::string, int x, int y): Base class constructor which currently takes in three parameters, std::string name, int x, and int y, and assigns them to the attributes name_, x_, and y_
2. LandBasedRobot(const LandBasedRobot &source): Base class copy constructor which takes in one parameter, const LandBasedRobot &source, and performs a deep copy operation on each of the elements/attributes contained within the LandBasedRobot object being copied
3. ~LandBasedRobot(): Base class destructor
4. GoUp(int x, int y): Pure virtual method that takes in two parameters, intx and int y, which will move the robot up in the maze
5. GoDown(int x, int y): Pure virtual method that takes in two parameters, intx and int y, which will move the robot down in the maze
6. TurnLeft(int x, int y): Pure virtual method that takes in two parameters, intx and int y, which will move the robot left in the maze
7. TurnRight(int x, int y): Pure virtual method that takes in two parameters, intx and int y, which will move the robot right in the maze
8. PickUp(std::string object): Virtual method that takes in one parameter, std::string, which will cause the robot to pick up an object in the maze
9. Release(std::string object): Virtual method that takes in one parameter, std::string, which will cause the robot to release an object in the maze
10. get_x(): Accessor which returns the protected x attribute that corresponds to the x coordinate of the robot's current position in the maze 
11. get_y(): Accessor which returns the protected y attribute that corresponds to the y coordinate of the robot's current position in the maze

LandBasedRobot Class (protected) Attributes
-----

1. std::string name_;// Name of the robot
2. double speed_;// Driving speed of the robot
3. double width_;// Width of the base of the robot
4. double length_;// Length of the base of the robot
5. double height_;// Height of the base of the robot
6. double capacity_;// Payload of the arm
7. int x_;// X coordinate of the robot in the maze
8. int y_;// Y coordinate of the robot in the maze 

LandBasedTracked Class (public) Methods
-----

1.  LandBasedTracked(std::string name, int x, int y): LandBasedRobot(name, x, y): Derived class constructor which currently takes in three parameters, std::string name, int x, and int y, and calls the Base class constructor LandBasedRobot() to assign values to the three parameters. The constructor dynamically allocates memory on the heap for all pointer attributes in the class and initializes them (currently to an empty sting (""))
2. LandBasedTracked(const LandBasedTracked &source): Derived class copy constructor which takes in one parameter, const LandBasedRobot &source, and performs a deep copy operation on each of the elements/attributes contained within the LandBasedRobot object being copied by calling the base class copy constructor and dynamically allocating memory on the heap for all pointer attributes in the class
3. ~LandBasedTracked(): Derived class destructor which also frees space allocated on the heap for the pointer attributes by calling delete on the pointers allocated by new
4. GoUp(int x, int y): Overrides the pure virtual method from the base class LandBasedRobot in order to move the robot up in the maze
5. GoDown(int x, int y): Overrides the pure virtual method from the base class LandBasedRobot in order to move the robot down in the maze
6. TurnLeft(int x, int y): Overrides the pure virtual method from the base class LandBasedRobot in order to move the robot left in the maze
7. TurnRight(int x, int y): Overrides the pure virtual method from the base class LandBasedRobot in order to move the robot right in the maze
8. PickUp(std::string object): Overrides the virtual method from the base class LandBasedRobot that takes in one parameter, std::string, which will cause the robot to pick up an object in the maze
9. Release(std::string object): Overrides virtual method from the base class LandBasedRobot that takes in one parameter, std::string, which will cause the robot to release an object in the maze

LandBasedTracked Class (protected) Attributes
-----

1. std::string *track_type;// Type of track mounted on the robot

LandBasedWheeled Class (public) Methods
-----

1.  LandBasedTracked(std::string name, int x, int y): LandBasedRobot(name, x, y): Derived class constructor which currently takes in three parameters, std::string name, int x, and int y, and calls the Base class constructor LandBasedRobot() to assign values to the three parameters. The constructor dynamically allocates memory on the heap for all pointer attributes in the class and initializes them (currently to an empty sting (""))
2. LandBasedTracked(const LandBasedTracked &source): Derived class copy constructor which takes in one parameter, const LandBasedRobot &source, and performs a deep copy operation on each of the elements/attributes contained within the LandBasedRobot object being copied by calling the base class copy constructor and dynamically allocating memory on the heap for all pointer attributes in the class
3. ~LandBasedTracked(): Derived class destructor which also frees space allocated on the heap for the pointer attributes by calling delete on the pointers allocated by new
4. SpeedUp(int num_cells): Method that enables the robot to increase its speed, which is translated by the number of cells in the maze that the robot can traverse in each step 
5. GoUp(int x, int y): Overrides the pure virtual method from the base class LandBasedRobot in order to move the robot up in the maze
6. GoDown(int x, int y): Overrides the pure virtual method from the base class LandBasedRobot in order to move the robot down in the maze
7. TurnLeft(int x, int y): Overrides the pure virtual method from the base class LandBasedRobot in order to move the robot left in the maze
8. TurnRight(int x, int y): Overrides the pure virtual method from the base class LandBasedRobot in order to move the robot right in the maze
9. PickUp(std::string object): Overrides the virtual method from the base class LandBasedRobot that takes in one parameter, std::string, which will cause the robot to pick up an object in the maze
10. Release(std::string object): Overrides virtual method from the base class LandBasedRobot that takes in one parameter, std::string, which will cause the robot to release an object in the maze

LandBasedWheeled Class (protected) Attributes
-----

1. int wheel_number;// Number of wheels mounted on the robot
2. std::string *wheel_type;// Type of wheels mounted on the robot

















