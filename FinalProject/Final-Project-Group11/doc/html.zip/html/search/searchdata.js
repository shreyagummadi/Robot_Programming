var indexSectionsWithContent =
{
  0: "abcdefghilmnrstwxy~",
  1: "adlm",
  2: "f",
  3: "abdlmr",
  4: "acdgilmrstw~",
  5: "cdehlmnrstwxy",
  6: "bt",
  7: "e"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Pages"
};

