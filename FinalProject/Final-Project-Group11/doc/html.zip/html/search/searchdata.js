var indexSectionsWithContent =
{
  0: "adghlmnstw",
  1: "adhlm",
  2: "glms",
  3: "ntw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables"
};

