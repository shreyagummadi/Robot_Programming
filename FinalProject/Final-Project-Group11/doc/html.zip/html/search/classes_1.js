var searchData=
[
  ['direction',['Direction',['../struct_direction.html',1,'']]]
];
