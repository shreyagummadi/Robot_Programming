var searchData=
[
  ['ackreset',['ackReset',['../classfp_1_1_a_p_i.html#a0c30419c7237b12bc916ce17f93a5be4',1,'fp::API']]]
];
